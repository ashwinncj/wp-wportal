<div class="wrap">
    <h1></h1>
    <h2></h2>
    <table></table>
    <?php
    ?>
</div>