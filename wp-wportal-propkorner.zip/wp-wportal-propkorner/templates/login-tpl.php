<!--//Login form template-->
<div class="wrap">
    <h3>Login to the site to continue.</h3>
    <form action="" method="POST">
        <input type="email" required name="user_email" placeholder="Your Email"><br>
        <input type="password" required name="user_password" placeholder="Your Password"><br>
        <input type="text" value="true" name="signon" required hidden>
        <input type="submit" value="Login"><br>
    </form>
</div>