<div class="wrap">
    <h1>Propkorner <span class="portal-title"> >> Dashboard</span>    </h1>
    <hr>
    <?php
    ?>
    <h2>
    </h2>
</div>